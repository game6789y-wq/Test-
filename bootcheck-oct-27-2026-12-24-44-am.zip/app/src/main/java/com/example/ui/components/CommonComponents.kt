package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AsunaBorder
import com.example.ui.theme.AsunaChestnutGold
import com.example.ui.theme.AsunaChestnutLight
import com.example.ui.theme.AsunaCrimsonPrimary
import com.example.ui.theme.AsunaDarkBg
import com.example.ui.theme.AsunaGreenSuccess
import com.example.ui.theme.AsunaOrangeWarning
import com.example.ui.theme.AsunaRapierTeal
import com.example.ui.theme.AsunaSurfaceCard
import com.example.ui.theme.AsunaTextPrimary
import com.example.ui.theme.AsunaTextSecondary
import com.example.ui.theme.AsunaTextTertiary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    borderColor: Color = AsunaBorder,
    backgroundColor: Color = AsunaSurfaceCard,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(18.dp))
            .padding(18.dp)
    ) {
        content()
    }
}

@Composable
fun StatusBadge(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun AsunaHeroHeader(
    score: Int,
    gradeTitle: String,
    gradeColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(230.dp)
            .clip(RoundedCornerShape(22.dp))
            .border(1.5.dp, AsunaCrimsonPrimary.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
    ) {
        // Anime Hero Image: Yuuki Asuna in Knights of the Blood Oath uniform at Aincrad
        Image(
            painter = painterResource(id = R.drawable.img_asuna_hero_1793035180971),
            contentDescription = "Yuuki Asuna - Sword Art Online",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient scrim overlays for pristine anime readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.0f to Color.Transparent,
                        0.35f to AsunaDarkBg.copy(alpha = 0.70f),
                        1.0f to AsunaDarkBg.copy(alpha = 0.95f)
                    )
                )
        )

        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Asuna Avatar
                    Image(
                        painter = painterResource(id = R.drawable.img_asuna_avatar_1793035194678),
                        contentDescription = "Asuna Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, AsunaChestnutGold, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(
                        text = "THE FLASH · ASUNA",
                        color = AsunaCrimsonPrimary
                    )
                }

                StatusBadge(
                    text = gradeTitle,
                    color = gradeColor
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "SAO Aincrad · Boot Integrity",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AsunaChestnutLight
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "$score",
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            color = AsunaTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "/100 HP",
                            fontSize = 14.sp,
                            color = AsunaRapierTeal,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp, start = 4.dp)
                        )
                    }
                }

                SaoRadarVisualizer(
                    modifier = Modifier.size(64.dp),
                    pulseColor = AsunaCrimsonPrimary
                )
            }
        }
    }
}

@Composable
fun SaoRadarVisualizer(
    modifier: Modifier = Modifier,
    pulseColor: Color = AsunaCrimsonPrimary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "saoRadar")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "saoSweepAngle"
    )

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = size.minDimension / 2

        // Outer & inner rings in Asuna crimson / gold
        drawCircle(
            color = AsunaBorder,
            radius = radius,
            center = center,
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawCircle(
            color = AsunaChestnutGold.copy(alpha = 0.5f),
            radius = radius * 0.65f,
            center = center,
            style = Stroke(width = 1.dp.toPx())
        )
        drawCircle(
            color = AsunaRapierTeal.copy(alpha = 0.35f),
            radius = radius * 0.3f,
            center = center,
            style = Stroke(width = 1.dp.toPx())
        )

        // Crosshairs
        drawLine(
            color = AsunaBorder.copy(alpha = 0.4f),
            start = Offset(center.x, 0f),
            end = Offset(center.x, size.height),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = AsunaBorder.copy(alpha = 0.4f),
            start = Offset(0f, center.y),
            end = Offset(size.width, center.y),
            strokeWidth = 1.dp.toPx()
        )

        // Sweeping Lambent Light radar beam
        val rad = Math.toRadians(sweepAngle.toDouble())
        val beamEnd = Offset(
            (center.x + radius * cos(rad)).toFloat(),
            (center.y + radius * sin(rad)).toFloat()
        )
        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(pulseColor.copy(alpha = 0.1f), pulseColor),
                start = center,
                end = beamEnd
            ),
            start = center,
            end = beamEnd,
            strokeWidth = 2.5.dp.toPx()
        )

        // Center Blip
        drawCircle(
            color = AsunaRapierTeal,
            radius = 3.5.dp.toPx(),
            center = center
        )
    }
}

@Composable
fun SecurityScoreGauge(
    score: Int,
    gradeTitle: String,
    gradeColor: Color,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = score / 100f,
        animationSpec = tween(durationMillis = 1000),
        label = "scoreGauge"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(150.dp)
        ) {
            Canvas(modifier = Modifier.size(140.dp)) {
                val strokeWidth = 12.dp.toPx()
                // Track arc
                drawArc(
                    color = Color(0xFF2E121E),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
                // Score arc with Asuna crimson to gold gradient
                drawArc(
                    brush = Brush.sweepGradient(
                        0.0f to AsunaCrimsonPrimary,
                        0.5f to AsunaChestnutGold,
                        1.0f to gradeColor
                    ),
                    startAngle = 135f,
                    sweepAngle = 270f * animatedProgress,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$score",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Black,
                    color = AsunaTextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "/100 HP",
                    fontSize = 12.sp,
                    color = AsunaTextTertiary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        StatusBadge(
            text = gradeTitle,
            color = gradeColor
        )
    }
}

@Composable
fun PropertyRow(
    title: String,
    value: String,
    isSafe: Boolean? = null,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val clickableModifier = if (onClick != null) {
        modifier.clickable { onClick() }
    } else {
        modifier
    }

    Row(
        modifier = clickableModifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                color = AsunaTextSecondary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = AsunaTextPrimary,
                fontFamily = FontFamily.Monospace
            )
        }

        if (isSafe != null) {
            val statusColor = if (isSafe) AsunaGreenSuccess else AsunaOrangeWarning
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }

        if (onClick != null) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Details for $title",
                tint = AsunaCrimsonPrimary.copy(alpha = 0.85f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
