package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Yuuki Asuna (Sword Art Online - Knights of the Blood Oath) Theme Palette
val AsunaDarkBg = Color(0xFF13090E)
val AsunaSurface = Color(0xFF1C0D15)
val AsunaSurfaceVariant = Color(0xFF28141F)
val AsunaSurfaceCard = Color(0xFF22101A)
val AsunaBorder = Color(0xFF4A1F30)

// Knights of the Blood Oath Scarlet & Asuna's Chestnut Gold
val AsunaCrimsonPrimary = Color(0xFFFF334B)
val AsunaCrimsonDark = Color(0xFF8B0000)
val AsunaChestnutGold = Color(0xFFE59448)
val AsunaChestnutLight = Color(0xFFFFB86C)

// Lambent Light Rapier Blade & Healing Stacia Glow
val AsunaRapierTeal = Color(0xFF4EE3CE)
val AsunaGreenSuccess = Color(0xFF00E676)
val AsunaYellowWarning = Color(0xFFFFD54F)
val AsunaOrangeWarning = Color(0xFFFF9100)
val AsunaRedAlert = Color(0xFFFF2A4B)

// Typography & Text
val AsunaTextPrimary = Color(0xFFFFF6F8)
val AsunaTextSecondary = Color(0xFFD9B6C4)
val AsunaTextTertiary = Color(0xFF987282)

// Backwards compatibility aliases
val CyberDarkBg = AsunaDarkBg
val CyberSurface = AsunaSurface
val CyberSurfaceVariant = AsunaSurfaceVariant
val CyberSurfaceCard = AsunaSurfaceCard
val CyberBorder = AsunaBorder
val CyberCyanPrimary = AsunaCrimsonPrimary
val CyberCyanMuted = AsunaChestnutGold
val CyberGreenSuccess = AsunaGreenSuccess
val CyberYellowWarning = AsunaYellowWarning
val CyberOrangeWarning = AsunaOrangeWarning
val CyberRedAlert = AsunaRedAlert
val CyberPurple = AsunaChestnutGold
val CyberTextPrimary = AsunaTextPrimary
val CyberTextSecondary = AsunaTextSecondary
val CyberTextTertiary = AsunaTextTertiary
