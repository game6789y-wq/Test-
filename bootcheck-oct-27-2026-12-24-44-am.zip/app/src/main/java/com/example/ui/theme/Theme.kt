package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AsunaColorScheme = darkColorScheme(
    primary = AsunaCrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF590E1B),
    onPrimaryContainer = Color(0xFFFFD9DF),
    secondary = AsunaChestnutGold,
    onSecondary = Color(0xFF381B00),
    secondaryContainer = Color(0xFF5A2E00),
    onSecondaryContainer = Color(0xFFFFDCBE),
    tertiary = AsunaRapierTeal,
    onTertiary = Color(0xFF003732),
    tertiaryContainer = Color(0xFF005049),
    onTertiaryContainer = Color(0xFF6FF7E4),
    background = AsunaDarkBg,
    onBackground = AsunaTextPrimary,
    surface = AsunaSurface,
    onSurface = AsunaTextPrimary,
    surfaceVariant = AsunaSurfaceVariant,
    onSurfaceVariant = AsunaTextSecondary,
    error = AsunaRedAlert,
    onError = Color.White,
    errorContainer = Color(0xFF540012),
    onErrorContainer = Color(0xFFFFDAD9),
    outline = AsunaBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = AsunaColorScheme,
        typography = Typography,
        content = content
    )
}
